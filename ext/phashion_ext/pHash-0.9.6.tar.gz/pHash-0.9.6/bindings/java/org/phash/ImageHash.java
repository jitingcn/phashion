package org.phash;
public abstract class ImageHash extends Hash
{
}
